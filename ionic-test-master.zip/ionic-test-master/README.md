This is an internal test designed for new hires, please request test instructions from us.
This is changed by Yuri on 2018/2/22.
I hope you to hire me!!

Haha.
